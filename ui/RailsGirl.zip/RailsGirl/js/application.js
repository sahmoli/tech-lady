
$(document).ready(function(){
   $('#myCarousel').carousel()
})